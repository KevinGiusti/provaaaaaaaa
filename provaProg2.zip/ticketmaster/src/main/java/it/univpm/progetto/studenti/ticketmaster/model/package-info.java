/**
 * 
 * Package che contiene le classi model, cioè le classi utili a modellare gli oggetti
 * 
 * @author RoccoAnzivino
 *
 */
package it.univpm.progetto.studenti.ticketmaster.model;