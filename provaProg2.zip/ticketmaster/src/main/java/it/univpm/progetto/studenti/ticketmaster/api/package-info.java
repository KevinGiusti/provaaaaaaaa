/**
 * 
 * Package contenente le classi che gestiscono le chiamate alla API di ticketmaster
 * 
 * @author RoccoAnzivino
 *
 */
package it.univpm.progetto.studenti.ticketmaster.api;