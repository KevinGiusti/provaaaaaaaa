/**
 * 
 * Package che contiene le classi Parser, ovvero le classi 
 * che analizzano il json delle chiamate alle rotte delle API
 * 
 * @author RoccoAnzivino
 *
 */
package it.univpm.progetto.studenti.ticketmaster.parser;