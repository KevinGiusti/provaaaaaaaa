/**
 * 
 * Package contenente la classe Scanner per leggere da file gli stati
 * 
 * @author RoccoAnzivino
 * 
 */
package it.univpm.progetto.studenti.ticketmaster.scanner;