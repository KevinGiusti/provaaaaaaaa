/**
 * 
 * Package che contiene la classe che avvia SpringBoot e il relativo web service sulla porta 8080
 * 
 * @author RoccoAnzivino
 *
 */
package it.univpm.progetto.studenti.ticketmaster;