package it.univpm.progetto.studenti.ticketmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketmasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
